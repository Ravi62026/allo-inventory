---
name: AlloStock Design System
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#464554'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#767586'
  outline-variant: '#c7c4d7'
  surface-tint: '#494bd6'
  primary: '#4648d4'
  on-primary: '#ffffff'
  primary-container: '#6063ee'
  on-primary-container: '#fffbff'
  inverse-primary: '#c0c1ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#825100'
  on-tertiary: '#ffffff'
  tertiary-container: '#a36700'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-title:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-title-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  section-heading:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-main:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  card-padding: 24px
  section-gap: 64px
  gutter: 16px
  container-max: 1280px
---

## Brand & Style
The design system is engineered for a premium SaaS inventory reservation experience, specifically tailored for the health and wellness sector. The aesthetic sits at the intersection of high-utility productivity tools and modern fintech—drawing inspiration from the precision of Linear, the clarity of Stripe, and the breathability of Notion.

The personality is **precise, calm, and trustworthy**. It prioritizes information density without clutter, using generous whitespace to reduce cognitive load for users managing complex stock levels. The visual language utilizes a "Flat-Layered" approach: surfaces appear flat and structural, but subtle environmental shadows and tonal shifts communicate hierarchy and interactive states.

## Colors
The palette is rooted in a soft, off-white foundation to minimize eye strain during long working sessions. 

- **Foundation**: Use `#FAFAFA` for global backgrounds and `#FFFFFF` for interactive surfaces and cards.
- **Accents**: Indigo (`#6366F1`) serves as the primary action color, providing a professional and modern tech feel.
- **Semantic Logic**: Emerald is reserved for "In Stock" or "Success" states, Amber for "Low Stock" or "Pending Reservations," and Red for "Out of Stock" or "System Errors."
- **Borders**: All structural divisions use `#E5E7EB`. Avoid high-contrast black borders; keep the interface feeling open and light.

## Typography
This design system relies exclusively on **Inter** to maintain a systematic, utilitarian feel. 

- **Headlines**: Use tight letter-spacing (`-0.02em`) for large titles to maintain a "Stripe-like" premium look.
- **Labels**: Small labels use uppercase with increased tracking to ensure legibility and distinguish them from body text.
- **Data Display**: For SKU numbers or inventory counts, an optional monospaced font (JetBrains Mono) can be used to ensure numerical alignment in tables.
- **Hierarchy**: Use font weight rather than size to establish importance. Body text stays at a comfortable 15px for optimal readability in data-heavy views.

## Layout & Spacing
The layout follows a strict **8px linear grid**. 

- **Grid System**: Use a 12-column fluid grid for desktop with 16px gutters. For sidebars (e.g., inventory navigation), use a fixed width of 240px or 280px.
- **Rhythm**: Spacing between major page sections should be 64px to create the "breathable" feel characteristic of Notion.
- **Card Internals**: All cards must maintain a consistent 24px internal padding (`inset-6` in Tailwind-speak). 
- **Mobile**: Margins reduce to 16px. Section spacing reduces to 32px.

## Elevation & Depth
Depth is created through "Soft Stacking" rather than heavy skeuomorphism.

- **Level 0 (Background)**: `#FAFAFA` — The canvas.
- **Level 1 (Cards/Surfaces)**: `#FFFFFF` with a subtle `0 1px 3px rgba(0,0,0,0.08)` shadow and a 1px border of `#E5E7EB`.
- **Level 2 (Dropdowns/Modals)**: `#FFFFFF` with a more pronounced shadow: `0 10px 15px -3px rgba(0,0,0,0.1)`.
- **Interactions**: On hover, cards may transition to a slightly deeper shadow or a subtle primary-colored border-bottom to indicate interactivity.

## Shapes
The shape language is varied to create a distinct hierarchy between structural elements and interactive elements:

- **Cards**: 12px (`rounded-xl`) — Creates a soft, approachable frame for content.
- **Action Elements**: 8px (`rounded-lg`) — Used for buttons and input fields to feel precise.
- **Status Tags/Badges**: 6px — A tighter radius for small elements to prevent them from looking like "pills" unless specifically requested.
- **Icons**: Use 2px stroke weight (Lucide style) with slightly rounded joins to match the UI's geometry.

## Components
- **Buttons**: Primary buttons use the Indigo background with white text. Secondary buttons use a white background with a `#E5E7EB` border. Ghost buttons are reserved for utility actions in sidebars.
- **Input Fields**: 8px radius, `#FFFFFF` background, and 1px border. Focus state should use a 2px indigo ring with 0% offset.
- **Inventory Chips**: Small badges with 6px radius. Use light tinted backgrounds (e.g., 10% opacity of the semantic color) with high-contrast text of the same hue for "In Stock" or "Low Stock" indicators.
- **Data Tables**: Remove vertical borders. Use horizontal dividers only. Table headers use the `label-caps` typography style.
- **Inventory Reservation Timer**: Use the Amber (`#F59E0B`) color with a countdown icon to create a sense of gentle urgency without inducing anxiety.
- **Empty States**: Use monochromatic Lucide icons paired with `body-main` text to maintain the "clean and breathable" ethos.